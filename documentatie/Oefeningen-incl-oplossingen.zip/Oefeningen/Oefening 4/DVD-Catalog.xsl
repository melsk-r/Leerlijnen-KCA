<?xml version='1.0'?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:template match="DVD-Catalog">
	<html>
		<head>
			<title>DVD Catalog</title>
			<style>
				h1	{
					margin:0cm;
					font-size:12.0pt;
					font-family:Verdana;
				}
				h2	{
					margin-top:0.5cm;
					font-size:11.0pt;
					font-family:Verdana;
					color:#CC6600
				}
				h3	{
					margin-left:0.6cm;
					font-size:10.0pt;
					font-family:Verdana;
				}
				p, td, span, font, li	{
					font-size:10.0pt;
					font-family:Verdana;
				}
				.Label	{
					font-weight:Bold;
				}
			</style>
		</head>
		<body>
			<table width="525">
				<tr>
					<td>
						<xsl:apply-templates select="DVD"/>
					</td>
				</tr>
			</table>
		</body>
	</html>
</xsl:template>

<xsl:template match="DVD">
	<div id="{ProductDetails/ASIN}" style="margin-bottom:20pt">
		<h1>
			<xsl:value-of select="Title"/>
			<xsl:if test="Subtitle">
				<xsl:text> - </xsl:text><xsl:value-of select="Subtitle"/>
			</xsl:if>
			<xsl:if test="@EditionType='Widescreen'">
				<xsl:text> (Widescreen Edition)</xsl:text>
			</xsl:if>
			<xsl:text> (</xsl:text><xsl:value-of select="@ReleaseYear"/>)
		</h1>
		<table width="525">
			<tr>
				<td width="150">
					<img src="..\{Cover/@File}"/>
				</td>
				<td valign="top">
					<xsl:apply-templates select="Price"/>
				</td>
			</tr>
		</table>
		<xsl:apply-templates select="ProductDetails"/>
	</div>
	<hr/>
</xsl:template>

<xsl:template match="Price">
	<xsl:variable name="Currency">
		<xsl:choose>
			<xsl:when test="@Currency='Dollar'">
				<xsl:value-of select="'$'"/>
			</xsl:when>
			<xsl:when test="@Currency='Euro'">
				<xsl:value-of select="''"/>
			</xsl:when>
			<xsl:when test="@Currency='Yen'">
				<xsl:value-of select="''"/>
			</xsl:when>
		</xsl:choose>
	</xsl:variable>
	<table>
		<tr>
			<td align="right" width="75">
				<p class="Label">List Price:</p>
			</td>
			<td width="3"/>
			<td>
				<p><strike><xsl:value-of select="$Currency"/><xsl:value-of select="ListPrice/Sum"/></strike></p>
			</td>
		</tr>
		<tr>
			<td align="right">
				<p class="Label">Price:</p>
			</td>
			<td/>
			<td>
				<p>
					<b><font style="color:#990000"><xsl:value-of select="$Currency"/><xsl:value-of select="ActualPrice/Sum"/></font></b>
					<xsl:if test="ActualPrice[@Eligibility='Free Super Saver Shipping']">
						<xsl:text> &amp; eligible for </xsl:text><b>FREE Super Saver Shipping</b><xsl:text> on orders over $25.</xsl:text>
					</xsl:if>
				</p>
			</td>
		</tr>
		<tr>
			<td align="right">
				<p class="Label">You Save:</p>
			</td>
			<td/>
			<td>
				<p><xsl:value-of select="$Currency"/><xsl:value-of select="Saving/Sum"/> (<xsl:apply-templates select="Saving/Percentage"/>%)</p>
			</td>
		</tr>
	</table>
</xsl:template>

<xsl:template match="ProductDetails">
	<h2>Product Details</h2>
	<ul>
		<xsl:apply-templates select="Starring"/>
		<xsl:apply-templates select="Directoring"/>
		<xsl:apply-templates select="Encoding"/>
		<xsl:apply-templates select="Format"/>
		<xsl:apply-templates select="Studio"/>
		<xsl:apply-templates select="DVDReleaseDate"/>
		<xsl:apply-templates select="DVDFeatures"/>
		<xsl:apply-templates select="ASIN"/>
	</ul>
</xsl:template>

<xsl:template match="Starring">
	<li>
		<xsl:call-template name="DetailLabel">
			<xsl:with-param name="Text" select="'Starring'"/>
		</xsl:call-template>
		<xsl:apply-templates select="Star"/>
	</li>
</xsl:template>

<xsl:template match="Star | Director">
	<xsl:choose>
		<xsl:when test="position()!=1">
			, <xsl:value-of select="."/>
		</xsl:when>
		<xsl:otherwise>
			<xsl:value-of select="."/>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template match="Directoring">
	<li>
		<xsl:call-template name="DetailLabel">
			<xsl:with-param name="Text" select="'Director'"/>
		</xsl:call-template>
		<xsl:apply-templates select="Director"/>
	</li>
</xsl:template>

<xsl:template match="Encoding">
	<li>
		<xsl:call-template name="DetailLabel">
			<xsl:with-param name="Text" select="'Encoding'"/>
		</xsl:call-template>
		<xsl:choose>
			<xsl:when test="count(Region)=1">
				<xsl:apply-templates select="Region"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:apply-templates select="Region">
					<xsl:with-param name="RegionCount" select="'more'"/>
				</xsl:apply-templates>
			</xsl:otherwise>
		</xsl:choose>
	</li>
</xsl:template>

<xsl:template match="Region">
	<xsl:param name="RegionCount" select="'one'"/>
	<xsl:variable name="Countries">
		<xsl:choose>
			<xsl:when test=".=1">
				<xsl:value-of select="'U.S. and Canada'"/>
			</xsl:when>
			<xsl:when test=".=2">
				<xsl:value-of select="'Latin America'"/>
			</xsl:when>
			<xsl:when test=".=3">
				<xsl:value-of select="'Europe'"/>
			</xsl:when>
			<xsl:when test=".=4">
				<xsl:value-of select="'Asia / Pacific'"/>
			</xsl:when>
			<xsl:when test=".=5">
				<xsl:value-of select="'Australia'"/>
			</xsl:when>
			<xsl:when test=".=6">
				<xsl:value-of select="'Africa'"/>
			</xsl:when>
		</xsl:choose>
	</xsl:variable>
	<xsl:choose>
		<xsl:when test="$RegionCount='one'">
			Region <xsl:value-of select="."/> (<xsl:value-of select="$Countries"/> only. This DVD will probably NOT be viewable in other countries.)
		</xsl:when>
		<xsl:otherwise>
			<xsl:choose>
				<xsl:when test="position()!=1">
					, Region <xsl:value-of select="."/> (<xsl:value-of select="$Countries"/>)
				</xsl:when>
				<xsl:otherwise>
					Region <xsl:value-of select="."/> (<xsl:value-of select="$Countries"/>)
				</xsl:otherwise>
			</xsl:choose>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template match="Format">
	<li>
		<xsl:call-template name="DetailLabel">
			<xsl:with-param name="Text" select="'Format'"/>
		</xsl:call-template>
		<xsl:apply-templates select="Item"/>
	</li>
</xsl:template>

<xsl:template match="Item">
	<xsl:choose>
		<xsl:when test="position()!=1">
			<xsl:text>, </xsl:text><xsl:value-of select="."/>
		</xsl:when>
		<xsl:otherwise>
			<xsl:value-of select="."/>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template match="Studio">
	<li>
		<xsl:call-template name="DetailLabel">
			<xsl:with-param name="Text" select="'Studio'"/>
		</xsl:call-template>
		<xsl:value-of select="."/>
	</li>
</xsl:template>

<xsl:template match="DVDReleaseDate">
	<li>
		<xsl:call-template name="DetailLabel">
			<xsl:with-param name="Text" select="'DVD Release Date'"/>
		</xsl:call-template>
		<xsl:variable name="Month">
			<xsl:choose>
				<xsl:when test="substring(.,6,2)='01'">
					<xsl:text>January </xsl:text>
				</xsl:when>
				<xsl:when test="substring(.,6,2)='02'">
					<xsl:text>February </xsl:text>
				</xsl:when>
				<xsl:when test="substring(.,6,2)='03'">
					<xsl:text>March </xsl:text>
				</xsl:when>
				<xsl:when test="substring(.,6,2)='04'">
					<xsl:text>April </xsl:text>
				</xsl:when>
				<xsl:when test="substring(.,6,2)='05'">
					<xsl:text>May </xsl:text>
				</xsl:when>
				<xsl:when test="substring(.,6,2)='06'">
					<xsl:text>June </xsl:text>
				</xsl:when>
				<xsl:when test="substring(.,6,2)='07'">
					<xsl:text>July </xsl:text>
				</xsl:when>
				<xsl:when test="substring(.,6,2)='08'">
					<xsl:text>August </xsl:text>
				</xsl:when>
				<xsl:when test="substring(.,6,2)='09'">
					<xsl:text>September </xsl:text>
				</xsl:when>
				<xsl:when test="substring(.,6,2)='10'">
					<xsl:text>October </xsl:text>
				</xsl:when>
				<xsl:when test="substring(.,6,2)='11'">
					<xsl:text>November </xsl:text>
				</xsl:when>
				<xsl:when test="substring(.,6,2)='12'">
					<xsl:text>December </xsl:text>
				</xsl:when>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="Day">
			<xsl:choose>
				<xsl:when test="substring(.,9,1)='0'">
					<xsl:value-of select="substring(.,10,1)"/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of select="substring(.,9,2)"/>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<xsl:value-of select="$Month"/> <xsl:value-of select="$Day"/>, <xsl:value-of select="substring(.,1,4)"/>
	</li>
</xsl:template>

<xsl:template match="ASIN">
	<li>
		<xsl:call-template name="DetailLabel">
			<xsl:with-param name="Text" select="'ASIN'"/>
		</xsl:call-template>
		<xsl:value-of select="."/>
	</li>
</xsl:template>

<xsl:template match="DVDFeatures">
	<li>
		<xsl:call-template name="DetailLabel">
			<xsl:with-param name="Text" select="'DVD Features'"/>
		</xsl:call-template>
		<xsl:choose>
			<xsl:when test="Disc">
				<xsl:apply-templates select="Disc"/>
			</xsl:when>
			<xsl:otherwise>
				<ul style="margin-left:1cm">
					<xsl:apply-templates select="Feature"/>
				</ul>
			</xsl:otherwise>
		</xsl:choose>
	</li>
</xsl:template>

<xsl:template name="DetailLabel">
	<xsl:param name="Text"/>
	<span class="Label"><xsl:value-of select="$Text"/>: </span>
</xsl:template>

<xsl:template match="Disc">
	<h3><xsl:apply-templates select="Title"/></h3>
	<ul style="margin-left:1cm">
		<xsl:apply-templates select="Feature"/>
	</ul>
</xsl:template>

<xsl:template match="Feature">
	<li>
		<xsl:value-of select="Bodytext"/>
		<xsl:apply-templates select="List"/>
		<xsl:apply-templates select="Duration"/>
		<xsl:apply-templates select="Remark"/>
	</li>
</xsl:template>

<xsl:template match="List">
	<ul>
		<xsl:apply-templates select="Listitem"/>
	</ul>
</xsl:template>

<xsl:template match="Listitem">
	<li>
		<xsl:value-of select="Bodytext"/>
		<xsl:apply-templates select="Duration"/>
		<xsl:apply-templates select="Remark"/>
	</li>
</xsl:template>

<xsl:template match="Duration">
	(<xsl:choose>
		<xsl:when test="contains(.,'H')">
			<xsl:choose>
				<xsl:when test="contains(.,'M')">
					<xsl:choose>
						<xsl:when test="contains(.,'S')">
							<xsl:value-of select="substring-before(substring-after(.,'PT'),'H')"/>.<xsl:value-of select="substring-before(substring-after(.,'H'),'M')"/>:<xsl:value-of select="substring-before(substring-after(.,'M'),'S')"/>
						</xsl:when>
					</xsl:choose>
				</xsl:when>
				<xsl:when test="contains(.,'S')">
					<xsl:value-of select="substring-before(substring-after(.,'PT'),'H')"/>.<xsl:value-of select="substring-before(substring-after(.,'H'),'S')"/>
				</xsl:when>
			</xsl:choose>
		</xsl:when>
		<xsl:when test="contains(.,'M')">
			<xsl:choose>
				<xsl:when test="contains(.,'S')">
					<xsl:value-of select="substring-before(substring-after(.,'PT'),'M')"/>:<xsl:value-of select="substring-before(substring-after(.,'M'),'S')"/>
				</xsl:when>
			</xsl:choose>
		</xsl:when>
		<xsl:when test="contains(.,'S')">
			<xsl:value-of select="substring-before(substring-after(.,'PT'),'S')"/>
		</xsl:when>
	</xsl:choose>
	<xsl:choose>
		<xsl:when test="../Remark">
			<xsl:text>, </xsl:text>
		</xsl:when>
		<xsl:otherwise>)</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template match="Remark">
	<xsl:choose>
		<xsl:when test="../Duration"/>
		<xsl:otherwise>(</xsl:otherwise>
	</xsl:choose>
	<xsl:value-of select="."/>)
</xsl:template>
</xsl:stylesheet><!-- Stylus Studio meta-information - (c)1998-2003 Copyright Sonic Software Corporation. All rights reserved.
<metaInformation>
<scenarios ><scenario default="yes" name="DVD&#x2D;Catalog" userelativepaths="yes" externalpreview="no" url="DVD&#x2D;Catalog.xml" htmlbaseurl="" outputurl="DVD&#x2D;Catalog.htm" processortype="internal" commandline="" additionalpath="" additionalclasspath="" postprocessortype="none" postprocesscommandline="" postprocessadditionalpath="" postprocessgeneratedext=""/></scenarios><MapperInfo srcSchemaPath="" srcSchemaRoot="" srcSchemaPathIsRelative="yes" srcSchemaInterpretAsXML="no" destSchemaPath="" destSchemaRoot="" destSchemaPathIsRelative="yes" destSchemaInterpretAsXML="no"/>
</metaInformation>
-->